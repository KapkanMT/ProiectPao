# Proiect-MDS
link catre Trello: https://trello.com/mds_group1/home



UML Link:https://docdro.id/b2q00Wc
